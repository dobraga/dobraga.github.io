---
title: "First snippet"
---

This content is in `snippets/first/index.md`

```sh
pwd
```
